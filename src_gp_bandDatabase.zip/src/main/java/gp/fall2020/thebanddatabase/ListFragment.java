package gp.fall2020.thebanddatabase;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

import java.util.List;

public class ListFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_list, container, false);
        LinearLayout layout = (LinearLayout) view;

        //Create the buttons using the band names and ids from BandDatabase
        List<Band> bandList = BandDatabase.getInstance(getContext()).getBands();
        for(int i=0; i<bandList.size(); i++) {
            Button button = new Button(getContext());
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            layoutParams.setMargins(0,0,0,10);
            button.setLayoutParams(layoutParams); //set button layout

            //set text to band's name and tag to band id
            Band band = BandDatabase.getInstance(getContext()).getBand(i+1);
            button.setText(band.getmName());
            button.setTag(Integer.toString(band.getmId()));

            //all buttons have same click listener
            button.setOnClickListener(buttonClickListener);

            //add button to linearlayout
            layout.addView(button);
        }
        return view;
    }

    private View.OnClickListener buttonClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            //send band id of clicked button to detailsactivity
            Intent intent = new Intent(getActivity(), DetailsActivity.class);
            String bandID = (String) view.getTag();
            intent.putExtra(DetailsActivity.EXTRA_BAND_ID, Integer.parseInt(bandID));
            startActivity(intent);
        }
    };
}